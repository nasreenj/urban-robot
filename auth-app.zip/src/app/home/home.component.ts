﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { User } from '../_models';
import { UserService } from '../_services';

@Component({templateUrl: 'home.component.html'})
export class HomeComponent implements OnInit {
    userNotes: any;
    currentUser: User;
    users: User[] = [];
    newnote = false;
    noteText: string;
    noteTime = new Date();
    constructor(private userService: UserService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.userNotes = this.currentUser['userNotes'];
    }

    ngOnInit() {
        this.loadAllUsers();
    }

    deleteUser(id: number) {
        this.userService.delete(id).pipe(first()).subscribe(() => { 
            this.loadAllUsers() 
        });
    }

    private loadAllUsers() {
        this.userService.getAll().pipe(first()).subscribe(users => { 
            this.users = users; 
        });
    }

    deleteNote(id) {
      this.userNotes.splice(this.userNotes.indexOf(id), 1);
      this.saveUserChanges();
    }
    editNote(note) {
      note.edit = true;
    }

    cancelNote(note){
      if (note === 'new') {
        this.newnote = false;
      } else {
        note.edit = false;

      }
    }
    saveNote(note) {
      if (note === 'new') {
        const objec = {
          noteText: this.noteText,
          remindTime : this.noteTime
        };
        this.userNotes.push(objec);

        this.newnote = false;
        this.noteText = '';
        this.noteTime = new Date();
      } else {
        note.edit = false;
      }
      this.saveUserChanges();
    }

    openNewNote() {
      this.newnote = true;
    }

    saveUserChanges(){
      this.users.map((data) => {
        if (data.id === this.currentUser.id) {
          data['userNotes'] = this.userNotes;
          this.currentUser['userNotes'] = this.userNotes;
        }
      });
      localStorage.setItem('users', JSON.stringify(this.users));
    }
}

